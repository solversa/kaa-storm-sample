/*
 * Copyright 2014-2016 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

# include <inttypes.h>
# include <string.h>
# include "../platform/stdio.h"
# include "kaa_logging_gen.h"
# include "../avro_src/avro/io.h"
# include "../avro_src/encoding.h"
# include "../utilities/kaa_mem.h"

/*
 * AUTO-GENERATED CODE
 */




static void kaa_logging_power_sample_serialize(avro_writer_t writer, void *data)
{
    if (data) {
        kaa_logging_power_sample_t *record = (kaa_logging_power_sample_t *)data;

        kaa_int_serialize(writer, &record->zone_id);
        kaa_int_serialize(writer, &record->panel_id);
        kaa_double_serialize(writer, &record->power);
    }
}

static size_t kaa_logging_power_sample_get_size(void *data)
{
    if (data) {
        size_t record_size = 0;
        kaa_logging_power_sample_t *record = (kaa_logging_power_sample_t *)data;

        record_size += kaa_int_get_size(&record->zone_id);
        record_size += kaa_int_get_size(&record->panel_id);
        record_size += AVRO_DOUBLE_SIZE;

        return record_size;
    }

    return 0;
}

kaa_logging_power_sample_t *kaa_logging_power_sample_create(void)
{
    kaa_logging_power_sample_t *record = 
            (kaa_logging_power_sample_t *)KAA_CALLOC(1, sizeof(kaa_logging_power_sample_t));

    if (record) {
        record->serialize = kaa_logging_power_sample_serialize;
        record->get_size = kaa_logging_power_sample_get_size;
        record->destroy = kaa_data_destroy;
    }

    return record;
}

kaa_logging_power_sample_t *kaa_logging_power_sample_deserialize(avro_reader_t reader)
{
    kaa_logging_power_sample_t *record = 
            (kaa_logging_power_sample_t *)KAA_MALLOC(sizeof(kaa_logging_power_sample_t));

    if (record) {
        record->serialize = kaa_logging_power_sample_serialize;
        record->get_size = kaa_logging_power_sample_get_size;
        record->destroy = kaa_data_destroy;

        avro_binary_encoding.read_int(reader, &record->zone_id);
        avro_binary_encoding.read_int(reader, &record->panel_id);
        avro_binary_encoding.read_double(reader, &record->power);
    }

    return record;
}



static void kaa_logging_power_report_destroy(void *data)
{
    if (data) {
        kaa_logging_power_report_t *record = (kaa_logging_power_report_t *)data;

                    kaa_list_destroy(record->samples, kaa_data_destroy);
                kaa_data_destroy(record);
    }
}

static void kaa_logging_power_report_serialize(avro_writer_t writer, void *data)
{
    if (data) {
        kaa_logging_power_report_t *record = (kaa_logging_power_report_t *)data;

        kaa_long_serialize(writer, &record->timestamp);
                    kaa_array_serialize(writer, record->samples, kaa_logging_power_sample_serialize);
                }
}

static size_t kaa_logging_power_report_get_size(void *data)
{
    if (data) {
        size_t record_size = 0;
        kaa_logging_power_report_t *record = (kaa_logging_power_report_t *)data;

        record_size += kaa_long_get_size(&record->timestamp);
                    record_size += kaa_array_get_size(record->samples, kaa_logging_power_sample_get_size);
            
        return record_size;
    }

    return 0;
}

kaa_logging_power_report_t *kaa_logging_power_report_create(void)
{
    kaa_logging_power_report_t *record = 
            (kaa_logging_power_report_t *)KAA_CALLOC(1, sizeof(kaa_logging_power_report_t));

    if (record) {
        record->serialize = kaa_logging_power_report_serialize;
        record->get_size = kaa_logging_power_report_get_size;
        record->destroy = kaa_logging_power_report_destroy;
    }

    return record;
}

kaa_logging_power_report_t *kaa_logging_power_report_deserialize(avro_reader_t reader)
{
    kaa_logging_power_report_t *record = 
            (kaa_logging_power_report_t *)KAA_MALLOC(sizeof(kaa_logging_power_report_t));

    if (record) {
        record->serialize = kaa_logging_power_report_serialize;
        record->get_size = kaa_logging_power_report_get_size;
        record->destroy = kaa_logging_power_report_destroy;

        avro_binary_encoding.read_long(reader, &record->timestamp);
            record->samples = kaa_array_deserialize_wo_ctx(reader, (deserialize_wo_ctx_fn)kaa_logging_power_sample_deserialize);
        }

    return record;
}

